# Collaborative Data Notebook (Demo)

## Quickstart with Docker

```bash
docker-compose up --build
```
- Frontend: http://localhost:5173
- Backend: http://localhost:8000
```
    