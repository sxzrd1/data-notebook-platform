import React, { useState, useEffect } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:8000");

export default function App() {
  const [text, setText] = useState("");

  useEffect(() => {
    socket.on("edit", (data) => setText(data));
    return () => socket.off("edit");
  }, []);

  const handleChange = (e) => {
    setText(e.target.value);
    socket.emit("edit", e.target.value);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Collaborative Data Notebook (Demo)</h1>
      <textarea
        style={{ width: "100%", height: "200px" }}
        value={text}
        onChange={handleChange}
      />
    </div>
  );
}
