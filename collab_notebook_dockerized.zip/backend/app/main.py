from fastapi import FastAPI
import socketio

sio = socketio.AsyncServer(cors_allowed_origins='*', async_mode='asgi')
app = FastAPI()
app.mount("/ws", socketio.ASGIApp(sio))

@app.get("/")
async def root():
    return {"message": "Backend running with FastAPI + Socket.IO"}

@sio.event
async def connect(sid, environ):
    print("Client connected:", sid)

@sio.event
async def disconnect(sid):
    print("Client disconnected:", sid)

@sio.event
async def edit(sid, data):
    await sio.emit("edit", data)
